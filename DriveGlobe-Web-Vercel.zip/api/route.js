// Vercel Function: /api/route
// Proxies OSRM Route service so the browser can fetch same-origin.
//
// Query params:
//   start=lon,lat
//   end=lon,lat
//
// OSRM Route service docs: /route/v1/{profile}/{coordinates}? ... &geometries=geojson&overview=full

export default async function handler(request) {
  const url = new URL(request.url);
  const start = url.searchParams.get('start');
  const end = url.searchParams.get('end');

  if (!start || !end) {
    return new Response(JSON.stringify({ error: 'Provide start and end query params as lon,lat.' }), {
      status: 400,
      headers: { 'content-type': 'application/json; charset=utf-8' },
    });
  }

  // Basic validation (lon,lat)
  function isLonLat(s) {
    const parts = s.split(',').map(Number);
    return parts.length === 2 && parts.every(Number.isFinite);
  }
  if (!isLonLat(start) || !isLonLat(end)) {
    return new Response(JSON.stringify({ error: 'start/end must look like "-122.42,37.77" (lon,lat).' }), {
      status: 400,
      headers: { 'content-type': 'application/json; charset=utf-8' },
    });
  }

  const osrm = new URL(`https://router.project-osrm.org/route/v1/driving/${start};${end}`);
  osrm.searchParams.set('overview', 'full');
  osrm.searchParams.set('geometries', 'geojson');
  osrm.searchParams.set('steps', 'false');

  try {
    const r = await fetch(osrm.toString(), { headers: { 'accept': 'application/json' } });
    const text = await r.text();
    if (!r.ok) {
      return new Response(JSON.stringify({ error: `OSRM error (${r.status})`, details: text }), {
        status: 502,
        headers: { 'content-type': 'application/json; charset=utf-8' },
      });
    }
    return new Response(text, {
      status: 200,
      headers: {
        'content-type': 'application/json; charset=utf-8',
        // Cache routes for a day (routes rarely change minute-to-minute)
        'cache-control': 'public, max-age=0, s-maxage=86400, stale-while-revalidate=604800',
      },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: 'Route fetch failed', details: String(e) }), {
      status: 502,
      headers: { 'content-type': 'application/json; charset=utf-8' },
    });
  }
}
