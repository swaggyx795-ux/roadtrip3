// Vercel Function: /api/weather
// Proxies The Weather Company "Currents on Demand" current observations endpoint.
//
// Requires env var: TWC_API_KEY
//
// Example endpoint + required parameters (geocode, units, language, format, apiKey):
// https://api.weather.com/v3/wx/observations/current?geocode=40.58,-111.66&units=e&language=en-US&format=json&apiKey=<yourApiKey>

export default async function handler(request) {
  const url = new URL(request.url);
  const lat = url.searchParams.get('lat');
  const lon = url.searchParams.get('lon');
  const units = url.searchParams.get('units') || 'e';

  const apiKey = process.env.TWC_API_KEY;
  if (!apiKey) {
    return new Response(JSON.stringify({ error: 'Missing TWC_API_KEY on server.' }), {
      status: 500,
      headers: { 'content-type': 'application/json; charset=utf-8' },
    });
  }

  const latNum = Number(lat);
  const lonNum = Number(lon);
  if (!Number.isFinite(latNum) || !Number.isFinite(lonNum)) {
    return new Response(JSON.stringify({ error: 'Provide lat and lon query params.' }), {
      status: 400,
      headers: { 'content-type': 'application/json; charset=utf-8' },
    });
  }

  const twc = new URL('https://api.weather.com/v3/wx/observations/current');
  twc.searchParams.set('geocode', `${latNum.toFixed(5)},${lonNum.toFixed(5)}`);
  twc.searchParams.set('units', units);
  twc.searchParams.set('language', 'en-US');
  twc.searchParams.set('format', 'json');
  twc.searchParams.set('apiKey', apiKey);

  try {
    const r = await fetch(twc.toString(), { headers: { 'accept': 'application/json' } });
    const text = await r.text();
    if (!r.ok) {
      return new Response(JSON.stringify({ error: `TWC error (${r.status})`, details: text }), {
        status: 502,
        headers: { 'content-type': 'application/json; charset=utf-8' },
      });
    }
    // pass through JSON as-is
    return new Response(text, {
      status: 200,
      headers: {
        'content-type': 'application/json; charset=utf-8',
        // cache briefly; currents update frequently
        'cache-control': 'public, max-age=0, s-maxage=60, stale-while-revalidate=300',
      },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: 'Weather fetch failed', details: String(e) }), {
      status: 502,
      headers: { 'content-type': 'application/json; charset=utf-8' },
    });
  }
}
