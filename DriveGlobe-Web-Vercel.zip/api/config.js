// Vercel Function: /api/config
// Returns non-secret runtime config to the client.
//
// NOTE: Cesium ion token isn't truly secret in a web app (it must be sent to the browser),
// but keeping it as an env var avoids hard-coding it in the repo.

export default function handler(request) {
  const body = {
    cesiumIonToken: process.env.CESIUM_ION_TOKEN || '',
    hasWeatherKey: Boolean(process.env.TWC_API_KEY),
  };

  return new Response(JSON.stringify(body), {
    status: 200,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      // cache a little to reduce function invocations
      'cache-control': 'public, max-age=0, s-maxage=60, stale-while-revalidate=300',
    },
  });
}
