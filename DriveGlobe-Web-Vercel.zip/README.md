# DriveGlobe (Workaround 2: Hosted Web App)

A browser-first "Google Earth vibe" driving simulator:
- 3D globe (CesiumJS via CDN)
- Real road route (OSRM Route service)
- A vehicle that drives at **75 mph** (simulation) from **San Francisco → Donner Summit**
- Real-time weather (The Weather Company "Currents on Demand") via serverless proxy

## Deploy with **no terminal** (Vercel + GitHub)
1. Create a GitHub repo (web UI), upload these files.
2. In Vercel, import the repo and set environment variables:
   - `CESIUM_ION_TOKEN` (Cesium ion access token)
   - `TWC_API_KEY` (The Weather Company Weather Data APIs key)
3. Deploy. Open the URL.

## Notes
- Offline: route continues moving, weather updates pause (browser can't fetch real-time data without network).
- Swap the vehicle model by changing `modelUrl` in `app.js`.
